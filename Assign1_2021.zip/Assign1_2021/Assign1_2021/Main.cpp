#include<stdio.h>
#include<conio.h>
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<iomanip>
#include<queue>
#include"Client.h"

using namespace std;

//define variables
vector <Client*> rsult;
//change this is read other files
string fileName = "Data1.txt";


//menu
string printmenu() {
    cout << "Assignment 1 Menu\n";
    cout << "E(xit)\n";
    cout << "R(ead)\n";
    cout << "Se(arch)\n";
    cout << "V(alue)\n";
    cout << "SO(rt)\n";
    cout << "SOB(ort)\n";
    cout << "P(ath)\n";
    cout << "F(ile name)\n";

    string choice;
    cout << "input selection: ";
    cin >> choice;
    cout << "\n";

    return choice;
}


//parse line code
Client* parse_line(string line)
{
    vector <string> store;
    string tok = "";
    Client* retv = nullptr;

    for (int i = 0; i < (int)line.size(); i++)
    {
        char c = line[i];
        if (c != ',' && c !='"')
        {
            tok = tok + c;
        }
        else if (c != ',' && c == '"')
        {
            char b = line[i + 1];
            while (b != '"')
            {   
                b = line[i + 1];
                if (b != ',' && b != '"') {
                    tok = tok + b;
                }
                i++;
            }
        }
        else
        {
            store.push_back(tok);
            tok = "";
        }
    }

    if (tok != ""){store.push_back(tok); }
    
    for (string s : store)
    {
        //cout << "DEBUG " << s << " | " << endl;
    }
  
    retv = new Client(store[0], store[1], stoi(store[2]), store[3], stod(store[4]), stod(store[5]), "");
    // var types
    // ID = store[0]
    // Name = store[1]
    // Postcode = store[2]
    // City = store[3]
    // ValuePur = store[4]
    // ValueRet = store[5]
    // CusID = store[6]

    return retv;
}


//will read into account
bool readFile() {
    //opens the file
    fstream myFile(fileName);

    //checks to open the file 
    if (!myFile.is_open())
    {
        cout << "File failed to open!" << endl;
        return false;
    }

    //variables
    string line;
    int i = 0;
    //goes through each line in the file
    while (getline (myFile, line))
    {
        //cout << "DEBUG -- line " << ++i << " is:" << line << endl;

        //ingnories line with a / at the start
        if (line[0] != '/')
        {
            //breaks up text with a ,
            Client* client = parse_line(line);
            rsult.push_back(client);
        }
        true;
    }
    myFile.close();
}


//compare postcode, old code, not used
bool Compare(Client* c1, Client* c2) {   
    return (c1->Postcode < c2->Postcode); 
}


//compares postcode and then name
bool Compareboth(Client* c1, Client* c2) {
    if (c1->Postcode == c2->Postcode) {
        return (c1->Name < c2->Name);
    }
    else {
        return (c1->Postcode < c2->Postcode);
    }
}


//sort function by postcode only
void sort(vector <Client*> varr)
{
    //use templete in tutorial
    cout << "Begin Sort \n";
    Client* temp;

    cout << "\n"; 

    //sort
    for (int i = 0; i < varr.size(); i++)
    {        
        for (int j = 1; j < varr.size(); j++)
        {            
            int c1 = varr[j]->Postcode;
            int c2 = varr[j - 1]->Postcode;
            if (c1 < c2)
            {               
                temp = varr[j];
                varr[j] = varr[j - 1];
                varr[j - 1] = temp;
            }        
        }    
    } 

    //print sorted vectors
    for (int i = 0; i < varr.size(); i++)
    { varr[i]->show();
    cout << " - [" << i << "]\n";
    } 
    cout << "End Sort \n";
}


//sorts by both name and postcode
void sortBoth()
{
    //general sort
    std::cout << "Sort Both\n";

    vector <Client*> temp;
    int VecLen = rsult.size();

    sort(rsult.begin(), rsult.end(), Compareboth);

    for (int i = 0; i < VecLen; i++)
    {
        rsult[i]->show();
        cout << " - [" << i << "]\n";
    }

    std::cout << "main1 - end Sort me please \n";
}


//search
void Search() {
    vector <Client*> temp;
    //make sure it is sorted
    sort(rsult.begin(), rsult.end(), Compareboth);

    cout << "Beginning search" << endl;

    //go through rsult printing out accounts with more than 25% return
    for (int i = 0; i < rsult.size(); i++) {
        if ((rsult[i]->ValuePur / 4) <= rsult[i]->ValueRet) {
            rsult[i]->show();
            cout << " - [" << i << "]\n";
        }
    }

    cout << "search end" << endl;

}


//checking report
void Report() {
    cout << "Checking Report" << endl;

    int VecLen = rsult.size();
    double totPur = 0;
    double totRet = 0;

    for (int i = 0; i < VecLen; i++)
    {
        totPur += rsult[i]->ValuePur;
        totRet += rsult[i]->ValueRet;
    }

    for (int i = 0; i < VecLen; i++)
    {
        rsult[i]->show();
        cout << " - [" << i << "]\n";
    }

    cout << "Count of Records: " << VecLen <<endl;
    cout << fixed << "Total Purchase: " << setprecision(2) << totPur << endl;
    cout << fixed << "Total Returns: " << setprecision(2) << totRet << endl;
}


void RenameFile() {

    string temp;

    cout << "What would you like to rename the file: ";
    cin >> temp;
    cout << endl;

    //converting strings into const char*
    char* oldName = new char[fileName.size() + 1];
    copy(fileName.begin(), fileName.end(), oldName);
    oldName[fileName.size()] = '\0'; // don't forget the terminating 0

    char* newName = new char[temp.size() + 1];
    copy(temp.begin(), temp.end(), newName);
    newName[temp.size()] = '\0'; // don't forget the terminating 0

    //cout << "/n" << "The file has been renamed: " << fileName << endl;


    rename(oldName, newName);

    // don't forget to free the string after finished using it
    delete[] oldName;
    delete[] newName;

    fileName = temp;

    cout << "Read File!\n";
    bool rc = readFile();

    Report();
}


int main(){ 
    //prints menu list
    string choice = printmenu();

    //selections
    //exit
    if (choice == "e" || choice == "E") {
        exit(1);
    }

    //read
    else if (choice == "r" || choice == "R") 
    {
        cout << "Read File!\n";
        bool rc = readFile();

        Report();

        //delete file
        //for (Client* t : rsult) delete t;

        //if (rc)
        //{
        //     cout << "Pointers cleared!\n";
        //}
    }

    //search
    else if (choice == "se" || choice == "Se" || choice == "SE") {
        Search();
    }

    //value
    else if (choice == "v" || choice == "V") {
        cout << "Value not implement" << endl;
    }

    //sort
    else if (choice == "so" || choice == "So" || choice == "SO") 
    {    
        sort(rsult);
    }

    //sortboth
    else if (choice == "sob" || choice == "Sob" || choice == "SOB") {
        sortBoth();
    }

    //path
    else if (choice == "p" || choice == "P") {
        cout << "Path not implement" << endl;
    }

    //file
    else if(choice == "f" || choice == "F") {
        RenameFile();
    }

    else {
        cout << "invalid input please try again";
    }

    main();
}

