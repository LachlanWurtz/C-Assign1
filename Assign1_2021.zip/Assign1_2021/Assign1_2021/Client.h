#pragma once
#include<stdio.h>
#include<conio.h>
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<iomanip>

using namespace std;

class Client {
public:
    string ID;
    string Name;
    int Postcode;
    string City;
    double ValuePur;
    double ValueRet;
    //this should be a pointer
    string CusID;

    Client();
    //cus id does nothing
    Client(string id, string name, int pc, string city, double varP, double varR, string cusid);
    void show();
};


Client::Client(string id, string name, int pc, string city, double varP, double varR, string cusid) //constructor
{
    this->ID= id;
    this->Name = name;
    this->Postcode = pc;
    this->City = city;
    this->ValuePur = varP;
    this->ValueRet = varR;
    //should be pointer to related enities
    this->CusID = cusid;
}


Client::Client() //default constructor
{
    string ID = "";
    string Name = "";
    int Postcode = NULL;
    string City = "";
    double ValuePur = NULL;
    double ValueRet = NULL;
    //point to null pointer
    string CusID = "";
}


//shows Client 
void Client::show()
{
    cout << fixed << setw(8) << ID << " " << setw(24) << Name << " " << setw(4) << Postcode << " " << setw(24) << City << " " << setprecision(2) << setw(12) << ValuePur << " " << setw(12) << ValueRet << " " << CusID;
}

